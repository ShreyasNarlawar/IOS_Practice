//
//  ContentView.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//
import SwiftUI

struct ContentView: View {
    @AppStorage("isDarkMode") var isDarkMode = false
    @StateObject private var viewModel = ProdViewModel()
    @StateObject private var orientation = OrientationManager()
    @State private var showToast = false
    @State private var toastMessage: String =  ""
    
    var body: some View {
        NavigationView {
            contentLayout
                .navigationTitle("Products")
            .toolbar {
                HStack {
                    // Add Button
                    NavigationLink(destination: AddProductView(viewModel: viewModel)) {
                        Image(systemName: "plus")
                            .foregroundColor(.purple)
                    }
                    
                    // Toggle Dark Mode
                    Button(action: {
                        withAnimation(.easeInOut(duration: 0.5)) {
                            isDarkMode.toggle()
                        }
                    }) {
                        Image(systemName: isDarkMode ? "sun.max.fill" : "moon.fill")
                            .font(.system(size: 18))
                            .foregroundColor(isDarkMode ? .orange : .gray)
                            .padding()
                    }
                }
            }
        }
        .toast(isShowing: $showToast, message: toastMessage)
        .preferredColorScheme(isDarkMode ? .dark : .light)
        .background(isDarkMode ? Color.black : Color.white)
        .ignoresSafeArea()
        
    }
    
    var contentLayout: some View{
        VStack(alignment: .leading){
                categoryPicker
                favouriteToggle
            
            if orientation.isPortrait {
                productList
            } else {
                HStack(alignment: .top){
                    Spacer(minLength: 20)
                    productList
                }
            }
        }
    }
    
    var categoryPicker: some View {
        Picker("Select Category", selection: $viewModel.selectedCategory) {
            ForEach(Category.allCases, id: \.self) { category in
                Text(category.rawValue).tag(category)
            }
        }
        .pickerStyle(SegmentedPickerStyle())
        .padding()
        .foregroundColor(isDarkMode ? .white : .black)
    }

    var favouriteToggle: some View {
            Toggle(isOn: $viewModel.FavOnly) {
                Text("Favourites Only")
                    .foregroundColor(isDarkMode ? .white : .mint)
            }
            .padding(.horizontal)
    }
    
    var productList: some View {
        List {
            ForEach(viewModel.filteredProducts) { prods in
                HStack {
                    NavigationLink(destination: ProdsDetailView(prod: prods, viewModel: viewModel)) {
                        VStack(alignment: .leading) {
                            Text(prods.name)
                                .font(.headline)
                            Text("₹\(prods.price, specifier: "%.2f")/-")
                                .font(.caption)
                                .foregroundColor(.mint)
                        }
                    }

                    Spacer()

                    // Toggle Favorite Button
                    Button(action: {
                        viewModel.toggleFav(for: prods)
                        toastMessage = prods.isFav ? "Removed from Favorites" : "Added to Favorites"
                        showToast = true
                    }) {
                        Image(systemName: prods.isFav ? "heart.fill" : "heart")
                            .foregroundColor(prods.isFav ? .red : .gray)
                    }
                    .buttonStyle(BorderedButtonStyle())
                }
                .padding(.vertical, 3)
            }
        }
        .listStyle(PlainListStyle())
        .scrollContentBackground(.hidden)
        .background(Color.clear)
    }

}
#Preview {
    ContentView()
}
