//
//  Orientation.swift
//  ProductProj0505
//
//  Created by Siddhatech on 07/05/25.
//

import SwiftUI
import Combine

class OrientationManager: ObservableObject {
    @Published var isPortrait: Bool = UIDevice.current.orientation.isPortrait
    private var cancellable: AnyCancellable?
    
    init() {
        self.listenOrientationChange()
    }
    
    private func listenOrientationChange(){
        cancellable = NotificationCenter.default.publisher(for: UIDevice.orientationDidChangeNotification)
            .sink{ _ in
                let orientation = UIDevice.current.orientation
                if orientation.isValidInterfaceOrientation{
                    self.isPortrait = orientation.isPortrait
                }
            }
    }
}
