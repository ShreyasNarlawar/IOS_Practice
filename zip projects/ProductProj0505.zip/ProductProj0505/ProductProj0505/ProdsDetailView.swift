//
//  ProdsDetailView.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//


import SwiftUI

struct ProdsDetailView: View {
    let prod:Product
    @ObservedObject var viewModel: ProdViewModel
    
    //these property always get the latest version of the product from the viewModel
    var updatedProd: Product {
           viewModel.products.first(where: { $0.id == prod.id }) ?? prod
       }
    var body: some View {
        VStack(spacing:20){
            Text(prod.name)
                .font(.title3)
                .fontWeight(.bold)
            
            Text("Category : \(prod.category.rawValue)")
                .font(.headline)
                .foregroundColor(.secondary)
            
            Text(String(format: "₹%.2f", prod.price))
                .font(.title)
                .foregroundColor(.primary)
            
            Spacer()
            
                NavigationLink(destination: EditProductView(viewModel: viewModel, product: updatedProd)){
                    VStack{
                        Image("Icons")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 40,height: 30)
                        Text("Edit").font(.caption)
                    }
                }
            .padding(.vertical,8)
        }
        .padding()
        .navigationTitle("Product Details")
        .font(.title3)
    }
}
