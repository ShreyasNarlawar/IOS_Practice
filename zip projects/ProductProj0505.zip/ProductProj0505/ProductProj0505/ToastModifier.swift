
//
//  ToastModifier.swift
//  ProductProj0505
//
//  Created by Siddhatech on 07/05/25.
//

import SwiftUI

struct ToastModifier: ViewModifier {
    
    @Binding var isShowing: Bool
    let message: String
    let duration: Double
    
    func body(content: Content) -> some View {
        ZStack {
            content
            
            if isShowing {
                VStack {
                    Spacer()
                    
                    Text(message)
                        .foregroundColor(.white.opacity(1.53))
                        .padding()
                        .background(Color.purple.opacity(0.32))
                        .cornerRadius(12)
                        .padding(.bottom, 40)
                        .transition(.move(edge: .bottom).combined(with: .opacity))
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + duration) {
                                withAnimation {
                                    isShowing = false
                                }
                            }
                        }
                }
                .animation(.easeInOut(duration: 0.3),value: isShowing)
            }
        }
    }
}
