//
//  ProdViewModel.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//
import SwiftUI
class ProdViewModel: ObservableObject{
    @Published var selectedCategory: Category = .all
    @Published var FavOnly: Bool = false
    @Published var products: [Product] = ProductData.allProducts
    
    // Store list of favorite product IDs using @AppStorage
    @AppStorage("FavProdId's")private var FavProdsIdsData: Data = Data()
    
    init(){
        self.products = ProductData.allProducts
        loadFavs()
    }
    
    var filteredProducts: [Product]{
        products.filter { product in
            let matchesCategory = selectedCategory == .all || product.category == selectedCategory
            let matchesFavourite = !FavOnly || product.isFav
            return matchesCategory && matchesFavourite
        }
    }
    
    func toggleFav(for product: Product){
        if let index = products.firstIndex(where: {$0.id == product.id}){
            products[index].isFav.toggle()
            saveFavs()
            ///This toggles the favorite state for a given product and saves it using saveFavs().
        }
    }
    
    private func saveFavs(){
        let favIds = products.filter{ $0.isFav }.map{$0.id.uuidString}
        if let data = try? JSONEncoder().encode(favIds){
            FavProdsIdsData = data
        }
    }
    
    private func loadFavs(){
        guard let favIds = try? JSONDecoder().decode([String].self, from: FavProdsIdsData) else {return}
        for index in products.indices{
            if favIds.contains(products[index].id.uuidString){
                products[index].isFav = true
            }
        }
    }
    
    func addNewProd(name: String, price: Double, category: Category){
        let newProduct = Product(id: UUID(), name: name, price: price, category: category)
        products.append(newProduct)
    }
    
    func EditProduct(_ updatedProduct: Product){
        if let index = products.firstIndex(where: { $0.id == updatedProduct.id }){
            products[index] = updatedProduct
            saveFavs()
            objectWillChange.send()
        }
    }
    
    func removeProduct(_ product:Product){
        if let index = products.firstIndex(where: {$0.id == product.id}){
            products.remove(at: index)
            saveFavs()
        }
    }
}

extension UIApplication {
    func endEditing() {
        sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

extension View {
    func toast(isShowing: Binding<Bool>, message: String, duration: Double = 2.0) -> some View {
        self.modifier(ToastModifier(isShowing: isShowing, message: message, duration: duration))
    }
}


