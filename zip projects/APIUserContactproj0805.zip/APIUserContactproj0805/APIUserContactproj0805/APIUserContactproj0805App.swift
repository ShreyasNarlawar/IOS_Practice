//
//  APIUserContactproj0805App.swift
//  APIUserContactproj0805
//
//  Created by Siddhatech on 08/05/25.
//

import SwiftUI

@main
struct APIUserContactproj0805App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
