//
//  ContentView.swift
//  APIUserContactproj0805
//
//  Created by Shreyas on 08/05/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
     UserListView()
    }
}

#Preview {
    ContentView()
}
