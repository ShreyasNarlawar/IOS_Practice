//
//  BooksApp1605App.swift
//  BooksApp1605
//
//  Created by Siddhatech on 19/05/25.
//

import SwiftUI

@main
struct BooksApp1605App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
