//
//  ContentView.swift
//  BooksApp1605
//
//  Created by Siddhatech on 19/05/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        BookListView()
    }
}

#Preview {
    ContentView()
}
