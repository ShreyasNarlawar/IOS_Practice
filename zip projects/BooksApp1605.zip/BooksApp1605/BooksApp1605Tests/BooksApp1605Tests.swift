//
//  BooksApp1605Tests.swift
//  BooksApp1605Tests
//
//  Created by Siddhatech on 19/05/25.
//

import Testing
@testable import BooksApp1605

struct BooksApp1605Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
