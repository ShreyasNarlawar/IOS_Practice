//
//  AddProductView.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//
import SwiftUI
import UIKit

struct AddProductView: View {
    @Environment(\.presentationMode) var presentationMode ///gives access to a special variable that helps you control the presentation of the view.
    @ObservedObject var viewModel: ProdViewModel
    
    @State private var name = ""
    @State private var price = ""
    @State private var category:Category = .all
    
    var body: some View {
        NavigationView{
            VStack{
                Form{
                    Section(header:Text("Add Product Details")){
                        TextField("Product Name",text: $name)
                        TextField("Product Price",text: $price)
                            .keyboardType(.decimalPad)
                        
                        Picker("Category",selection: $category){
                            ForEach(Category.allCases, id: \.self){ categ in
                                Text(categ.rawValue).tag(categ).padding(.bottom,10)
                            }
                        }
                    }
                }//.padding(.top,-280)
                
                Spacer()
            
            Button(action: {
                    if let priceValue = Double(price) {
                        viewModel.addNewProd(name: name, price: priceValue, category: category)
                        presentationMode.wrappedValue.dismiss()
                    }
                }){
                    Text("Add Product")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(25)
                        .padding(.horizontal)
                }
                .disabled(name.isEmpty || price.isEmpty)
                .padding(.bottom,5)
                //.background(Color(UIColor.systemBackground))
            }
            .navigationTitle("Add New Product")
            .dismissKeyboardOnTap()
        }
    }
}

#Preview {
   ContentView()
}
