//
//  Product.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//

import Foundation

enum Category: String, CaseIterable, Identifiable{
case all = "All"
case food = "Food"
case electronics = "Electronics"
case clothing = "Clothing"
case eyewear = "Eyewear"

var id: String{self.rawValue}
}

struct Product: Identifiable, Equatable{
let id: UUID
let name: String
let price: Double
let category: Category
var isFav: Bool = false
}

struct ProductData{
static let allProducts = [
    Product(id: UUID(), name: "Chips", price: 10.00, category: .food, isFav: false),
    Product(id: UUID(), name: "T-shirt", price: 99.00, category: .clothing, isFav: false),
    Product(id: UUID(), name: "Jeans", price: 1999.00, category: .clothing, isFav: false),
    Product(id: UUID(), name: "Pizza", price: 210.00, category: .food, isFav: false),
    Product(id: UUID(), name: "SunGlasses", price: 2950.00, category: .eyewear, isFav: false),
    Product(id: UUID(), name: "Goggles", price: 3210.00, category: .eyewear, isFav: false),
    Product(id: UUID(), name: "Dell Laptop", price: 69000.00, category: .electronics, isFav: false),
    Product(id: UUID(), name: "AC", price: 36999.99, category: .electronics, isFav: false)
]
}
