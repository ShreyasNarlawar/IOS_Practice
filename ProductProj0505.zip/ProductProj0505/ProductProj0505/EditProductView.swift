//
//  EditProductView.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//

import SwiftUI

struct EditProductView: View {
    @ObservedObject var viewModel: ProdViewModel
    @State private var name: String
    @State private var price: Double
    @State private var category: Category
    @Environment(\.dismiss) var dismiss
    
    let originalProd: Product
    
    init(viewModel: ProdViewModel, product: Product){
        self.viewModel = viewModel
        self._name = State(initialValue: product.name)
        self._price = State(initialValue: product.price)
        self._category = State(initialValue: product.category)
        self.originalProd = product
    }
    
    var body: some View {
        VStack{
            Form{
                Section{
                    TextField("Product Name", text: $name)
                    TextField("Product Price", value: $price, format: .number)
                        .keyboardType(.decimalPad)
                    
                    Picker("Category", selection: $category){
                        ForEach(Category.allCases, id: \.self){
                            Text($0.rawValue).tag($0)
                        }
                    }
                }
            }
            Button(action: {
                let updatedProd = Product(
                    id: originalProd.id,
                    name: name,
                    price: price,
                    category: category,
                    isFav: originalProd.isFav
                )
                viewModel.EditProduct(updatedProd)
                dismiss()
            }){
                Text("Save Changes")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.purple)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .padding(.horizontal)
            }
            .disabled(name.isEmpty || price <= 0)
            
            Button(role: .destructive) {
                viewModel.removeProduct(originalProd)
                dismiss()
            }label:{
                Text("Delete Product")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.red)
                    .foregroundColor(.white)
                    .cornerRadius(12)
                    .padding(.horizontal)
            }
            .padding(.bottom,1)
        }
        .navigationTitle("Edit Product")
        .dismissKeyboardOnTap()
    }
}
