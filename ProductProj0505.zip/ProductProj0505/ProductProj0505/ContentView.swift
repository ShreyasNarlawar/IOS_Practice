//
//  ContentView.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//

import SwiftUI

struct ContentView: View {
    @StateObject private var viewModel = ProdViewModel()
    var body: some View {
        NavigationView{
            VStack{
                //Used Picker to Sleect the Category
                Picker("Select Category",selection: $viewModel.selectedCategory){
                    ForEach(Category.allCases, id: \.self){ category in
                        Text(category.rawValue).tag(category)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding()
                
                ///Toggle Button for Favourite Only
                Toggle(isOn: $viewModel.FavOnly){
                    Text("Favourites Only")
                }
                .padding(.horizontal)
                .fontWeight(.light)
                .foregroundColor(.purple)
                
                ///To view Products List
                List{
                    ForEach(viewModel.filteredProducts){prods in
                        HStack{
                            NavigationLink(destination: ProdsDetailView(prod: prods, viewModel: viewModel)){
                                VStack(alignment: .leading){
                                    Text(prods.name)
                                    Spacer()
                                    Text("₹\(prods.price, specifier: "%.2f")/-")
                                        .font(.caption)
                                        .foregroundColor(.mint)
                                }
                            }
                            Spacer()
                            //Button to add Favourite
                            Button(action: {
                                viewModel.toggleFav(for:prods)
                            }){
                                Image(systemName: prods.isFav ? "heart.fill" : "heart")
                                    .foregroundColor(prods.isFav ? .red : .gray)
                            }
                            .buttonStyle(BorderedButtonStyle())
                        }
                        .listStyle(.automatic)
                    }
                }
            }
            .navigationTitle("Products")
            .toolbar{
                NavigationLink(destination: AddProductView(viewModel: viewModel)){
                    Image(systemName: "plus").foregroundColor(.purple)
                }
            }
        }
    }
}
#Preview {
    ContentView()
}
