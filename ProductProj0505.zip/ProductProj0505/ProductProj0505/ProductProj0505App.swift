//
//  ProductProj0505App.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//

import SwiftUI

@main
struct ProductProj0505App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
