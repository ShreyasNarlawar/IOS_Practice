//
//  KeyboardDismiss.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//

import SwiftUI

// View Modifier to Dismiss Keyboard when tapped outside
struct DismissKeyboardGesture: ViewModifier {
    func body(content: Content) -> some View {
        content
            .onTapGesture {
                UIApplication.shared.endEditing()  // Dismiss the keyboard
            }
    }
}

// Extends View to easily apply the modifier
extension View {
    func dismissKeyboardOnTap() -> some View {
        self.modifier(DismissKeyboardGesture()) //tells SwiftUI to modify the current view
    }
}
