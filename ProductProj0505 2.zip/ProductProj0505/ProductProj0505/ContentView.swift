//
//  ContentView.swift
//  ProductProj0505
//
//  Created by Shreyas on 06/05/25.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("isDarkMode") var isDarkMode = false
    @StateObject private var viewModel = ProdViewModel()
    
    var body: some View {
        Text("Loaded View").foregroundColor(.red)

        NavigationView{
            (isDarkMode ? Color.black : Color.white)
                .ignoresSafeArea()
                .animation(.easeInOut, value: isDarkMode)
            VStack{
                //Used Picker to Sleect the Category
                Picker("Select Category",selection: $viewModel.selectedCategory){
                    ForEach(Category.allCases, id: \.self){ category in
                        Text(category.rawValue).tag(category)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .foregroundColor(isDarkMode ? .white : .black)
                .padding()
                
                Spacer()
                
                //Toggle button for Dark Mode
                Button(action:{
                    withAnimation(.easeInOut(duration: 2.1)){
                        isDarkMode.toggle()
                    }
                }){
                    HStack{
                        Image(systemName: isDarkMode ? "sun.max.fill" : "moon.fill")
                            .font(.system(size: 25))
                            .padding()
                    }
                    .background(
                        Capsule()
                            .fill(isDarkMode ? Color.white.opacity(0.2) : Color.black.opacity(0.2))
                            .overlay(
                                Capsule().stroke(Color.gray.opacity(0.4), lineWidth: 0.5)
                            )
                    )
                }.padding()
                
                //Toggle Button for Favourite Only
                Toggle(isOn: $viewModel.FavOnly){
                    Text("Favourites Only")
                }
                .padding(.horizontal)
                .fontWeight(.light)
                .foregroundColor(isDarkMode ? .white : .mint)
                
                //To view Products List
                List{
                    ForEach(viewModel.filteredProducts){ prods in
                        HStack{
                            NavigationLink(destination: ProdsDetailView(prod: prods, viewModel: viewModel)){
                                VStack(alignment: .leading){
                                    Text(prods.name)
                                    Spacer()
                                    Text("₹\(prods.price, specifier: "%.2f")/-")
                                        .font(.caption)
                                        .foregroundColor(isDarkMode ? .white : .mint)
                                }
                            }
                            Spacer()
                            //Button to add Favourite
                            Button(action: {
                                viewModel.toggleFav(for:prods)
                            }){
                                Image(systemName: prods.isFav ? "heart.fill" : "heart")
                                    .foregroundColor(prods.isFav ? .red : .gray)
                            }
                            .buttonStyle(BorderedButtonStyle())
                        }
                    }
                }.listStyle(.automatic)
            }
            .navigationTitle("Products")
            .toolbar{
                NavigationLink(destination: AddProductView(viewModel: viewModel)){
                    Image(systemName: "plus")
                        .foregroundColor(.purple)
                }
            }
        }
        .preferredColorScheme(isDarkMode ? .dark : .light)
    }
}
#Preview {
    ContentView()
}
