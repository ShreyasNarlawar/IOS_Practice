//
//  ProductProj0505Tests.swift
//  ProductProj0505Tests
//
//  Created by Siddhatech on 06/05/25.
//

import Testing

struct ProductProj0505Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
